<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$pageTitle = 'All database tables';

require __DIR__ . '/includes/header.php';
?>

<div class="page-intro">

    <p>
        Choose a collection to browse, search, add, update or export its records.
    </p>

    <div class="export-actions">

        <span class="soft-tag">
            9 collections · MySQL connected
        </span>

        <a class="btn btn-small btn-soft"
           href="export.php?format=csv&amp;table=all">
            Export all CSV
        </a>

        <a class="btn btn-small btn-outline"
           href="export.php?format=pdf&amp;table=all">
            Export all PDF
        </a>

    </div>

</div>


<div class="collection-grid collection-grid-large">

    <?php foreach ($TABLES as $name => $cfg): ?>

        <a class="collection-card" href="table.php?name=<?= urlencode($name) ?>">

            <span class="collection-icon">
                <?= h($cfg['icon']) ?>
            </span>

            <span class="collection-name">
                <?= h($cfg['label']) ?>
            </span>

            <strong>
                <?= number_format(count_table($name)) ?>
            </strong>

            <small>
                records <span>↗</span>
            </small>

        </a>

    <?php endforeach; ?>

</div>


<section class="panel export-panel">

    <div>

        <span class="eyebrow">BACKUP & REPORTS</span>

        <h2>Export database tables</h2>

        <p>
            Download a CSV spreadsheet or PDF report for each of the nine collections.
        </p>

    </div>

    <div class="export-list">

        <?php foreach ($TABLES as $name => $cfg): ?>

            <div class="export-row">

                <span>
                    <?= h($cfg['icon']) ?>
                    <?= h($cfg['label']) ?>
                </span>

                <div>

                    <a class="btn btn-small btn-soft"
                       href="export.php?format=csv&amp;table=<?= urlencode($name) ?>">
                        CSV
                    </a>

                    <a class="btn btn-small btn-outline"
                       href="export.php?format=pdf&amp;table=<?= urlencode($name) ?>">
                        PDF
                    </a>

                </div>

            </div>

        <?php endforeach; ?>

    </div>

</section>

<?php require __DIR__ . '/includes/footer.php'; ?>