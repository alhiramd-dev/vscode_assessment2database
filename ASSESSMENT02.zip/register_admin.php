
<?php
require_once __DIR__ . '/includes/auth.php';

// Only logged-in Admin accounts can access this page.
if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

if (current_role() !== 'Admin') {
    http_response_code(403);
    exit('Access denied. Only Admin accounts can create Admin accounts.');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $full_name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (
        $full_name === '' || $username === '' || $email === '' ||
        $password === '' || $confirm_password === ''
    ) {
        $error = 'Please complete all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($username) < 4) {
        $error = 'Username must contain at least 4 characters.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must contain at least 8 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'The passwords do not match.';
    } else {
        $check = $pdo->prepare(
            "SELECT user_id FROM SystemUser
             WHERE username = :username OR email = :email
             LIMIT 1"
        );

        $check->execute([
            ':username' => $username,
            ':email' => $email
        ]);

        if ($check->fetch()) {
            $error = 'That username or email is already registered.';
        } else {
            $password_hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $insert = $pdo->prepare(
                "INSERT INTO SystemUser
                (username, password_hash, full_name, email, user_role, account_status)
                VALUES
                (:username, :password_hash, :full_name, :email, 'Admin', 'Active')"
            );

            $insert->execute([
                ':username' => $username,
                ':password_hash' => $password_hash,
                ':full_name' => $full_name,
                ':email' => $email
            ]);

            $success = 'New Admin account created successfully.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Admin | TVETMARA</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">

<main class="auth-card">

    <div class="auth-logo">
        <img src="assets/images/tvetmara-logo.png"
             alt="TVETMARA Logo"
             onerror="this.style.display='none';">
    </div>

    <p class="auth-institution">TVETMARA PETALING JAYA</p>
    <h1>Register Admin</h1>
    <p class="auth-subtitle">Create an additional administrator account.</p>

    <?php if ($error !== ''): ?>
        <div class="auth-alert auth-error"><?= h($error) ?></div>
    <?php endif; ?>

    <?php if ($success !== ''): ?>
        <div class="auth-alert auth-success"><?= h($success) ?></div>
    <?php endif; ?>

    <form method="POST" action="register_admin.php">
        <input type="hidden" name="csrf_token"
               value="<?= h(csrf_token()) ?>">

        <label for="full_name">Full name</label>
        <input type="text" id="full_name" name="full_name"
               placeholder="Enter full name" maxlength="100" required>

        <label for="username">Username</label>
        <input type="text" id="username" name="username"
               placeholder="Choose a username"
               minlength="4" maxlength="50" required>

        <label for="email">Email address</label>
        <input type="email" id="email" name="email"
               placeholder="Enter email address"
               maxlength="100" required>

        <label for="password">Password</label>
        <input type="password" id="password" name="password"
               placeholder="At least 8 characters"
               minlength="8" required>

        <label for="confirm_password">Confirm password</label>
        <input type="password" id="confirm_password"
               name="confirm_password"
               placeholder="Enter password again"
               minlength="8" required>

        <button type="submit" class="auth-button">
            Create Admin account ♡
        </button>
    </form>

    <p class="auth-footer">
        <a href="dashboard.php">Back to dashboard</a>
    </p>

    <p class="auth-security">✧ Admin-only account registration ✧</p>

</main>
</body>
</html>
