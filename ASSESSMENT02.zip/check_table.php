
<?php

require_once __DIR__ . '/includes/functions.php';

require_login();

$table = 'LecturerSupervisor';

$cfg = get_table_config($table);

echo '<h2>Table Page Diagnostic</h2>';

echo '<h3>1. Database connection</h3>';

echo '<pre>';
echo 'Database: ';
var_dump($pdo->query('SELECT DATABASE()')->fetchColumn());
echo '</pre>';

echo '<h3>2. SQL query result</h3>';

$stmt = $pdo->query("SELECT * FROM `$table` LIMIT 3");

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo '<pre>';
var_dump($rows);
echo '</pre>';

echo '<h3>3. Visible columns</h3>';

$visibleCols = [];

foreach ($cfg['columns'] as $column => $meta) {

    if (!empty($meta['show'])) {
        $visibleCols[] = $column;
    }

}

echo '<pre>';
var_dump($visibleCols);
echo '</pre>';

echo '<h3>4. Test table heading code</h3>';

foreach ($visibleCols as $col) {

    echo '<p>';

    echo 'Column: ' . htmlspecialchars($col);

    echo ' | Label: ' .
        htmlspecialchars($cfg['columns'][$col]['label'] ?? 'MISSING');

    echo '</p>';

}

echo '<h3>5. Test record values</h3>';

foreach ($rows as $row) {

    echo '<pre>';

    foreach ($visibleCols as $col) {

        echo htmlspecialchars($col) . ' = ';

        echo htmlspecialchars((string)($row[$col] ?? 'MISSING'));

        echo "\n";

    }

    echo '</pre>';

}

echo '<h3>Diagnostic completed.</h3>';

?>
