
<?php
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Please enter your username and password.';
    } else {
        $stmt = $pdo->prepare(
            "SELECT user_id, username, password_hash, full_name,
                    email, user_role, account_status
             FROM SystemUser
             WHERE username = :username
             LIMIT 1"
        );

        $stmt->execute([':username' => $username]);
        $user = $stmt->fetch();

        if (
            $user &&
            password_verify($password, $user['password_hash']) &&
            $user['account_status'] === 'Active'
        ) {
            session_regenerate_id(true);

            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['user_role'];

            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Login unsuccessful. Check your username, password and account status.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | TVETMARA Industrial Training</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">

<div class="auth-decoration flower-decoration">✿</div>
<div class="auth-decoration star-decoration">✧</div>

<main class="auth-card">
    <div class="auth-logo">
        <img
            src="assets/images/tvetmara-logo.png"
            alt="TVETMARA Logo"
            onerror="this.style.display='none';"
        >
    </div>

    <p class="auth-institution">TVETMARA PETALING JAYA</p>
    <h1>Welcome back!</h1>
    <p class="auth-subtitle">
        Your little workspace for industrial training records.
    </p>

    <?php if ($error !== ''): ?>
        <div class="auth-alert auth-error">
            <?= h($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">

        <label for="username">Username</label>
        <input
            type="text"
            id="username"
            name="username"
            placeholder="Enter your username"
            value="<?= h($_POST['username'] ?? '') ?>"
            autocomplete="username"
            required
        >

        <label for="password">Password</label>
        <input
            type="password"
            id="password"
            name="password"
            placeholder="Enter your password"
            autocomplete="current-password"
            required
        >

        <button type="submit" class="auth-button">
            Sign in ♡
        </button>
    </form>

    <p class="auth-footer">
        Don't have an account?
        <a href="register.php">Create an account</a>
    </p>

    <p class="auth-security">✧ Admin and Staff access · Secure sign in ✧</p>
</main>

</body>
</html>
