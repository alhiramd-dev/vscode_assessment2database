<?php

// FIRST-TIME LOCAL SETUP ONLY.
// Delete this file after setting up the required accounts.

require_once __DIR__ . '/includes/auth.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verify_csrf();

    $username = trim($_POST['username'] ?? '');

    $password = $_POST['password'] ?? '';

    $confirm = $_POST['confirm_password'] ?? '';


    if (strlen($password) < 8) {

        $error = 'Use a password with at least 8 characters.';

    } elseif ($password !== $confirm) {

        $error = 'The passwords do not match.';

    } else {

        $hash = password_hash(
            $password,
            PASSWORD_DEFAULT
        );

        $stmt = $pdo->prepare("
            UPDATE SystemUser
            SET password_hash = ?
            WHERE username = ?
            AND password_hash LIKE 'TEMP_HASH_%'
        ");

        $stmt->execute([
            $hash,
            $username
        ]);


        if ($stmt->rowCount() === 1) {

            $message =
                'Password set successfully for ' .
                $username .
                '. You can now sign in. Delete setup_accounts.php after setting the required accounts.';

        } else {

            $error =
                'No matching temporary account found. Check the username and make sure its password_hash still begins with TEMP_HASH_.';

        }

    }

}

?>

<!doctype html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Set up accounts</title>

    <link rel="stylesheet" href="assets/css/style.css">

</head>


<body class="login-body">

    <div class="login-card setup-card">

        <div class="login-logo">🔐</div>

        <h1>Set up login password</h1>

        <p class="muted">
            Use this one-time local setup page to replace the temporary
            B3 password values with secure password hashes.
        </p>


        <?php if ($message): ?>

            <div class="alert alert-success">
                <?= h($message) ?>
            </div>

        <?php endif; ?>


        <?php if ($error): ?>

            <div class="alert alert-error">
                <?= h($error) ?>
            </div>

        <?php endif; ?>


        <div class="setup-warning">

            Set at least one Admin account and one Staff account.

            Suggested usernames from your sample records:

            <b>admin01</b> and <b>staff01</b>.

        </div>


        <form method="post" class="form-stack">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= h(csrf_token()) ?>"
            >


            <label>
                Existing username

                <input
                    name="username"
                    required
                    placeholder="admin01"
                >
            </label>


            <label>
                New password

                <input
                    type="password"
                    name="password"
                    minlength="8"
                    required
                >
            </label>


            <label>
                Confirm password

                <input
                    type="password"
                    name="confirm_password"
                    minlength="8"
                    required
                >
            </label>


            <button class="btn btn-primary btn-wide">
                Save password securely
            </button>

        </form>


        <p class="login-foot">
            Important: delete setup_accounts.php after account setup.
        </p>

    </div>

</body>

</html>