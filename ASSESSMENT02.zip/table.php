
<?php
require_once __DIR__ . '/includes/functions.php';

require_login();

// Get the requested table name.
$table = $_GET['name'] ?? '';

// Validate the table using the existing table configuration.
$cfg = get_table_config($table);

$pageTitle = $cfg['label'];
$activeTable = $table;

$q = trim($_GET['q'] ?? '');

// ------------------------------------------
// 1. Prepare searchable columns
// ------------------------------------------

$searchCols = [];

foreach ($cfg['columns'] as $column => $meta) {
    if (
        !empty($meta['search']) &&
        !empty($meta['show'])
    ) {
        $searchCols[] = $column;
    }
}

// ------------------------------------------
// 2. Retrieve database records
// ------------------------------------------

$sql = "SELECT * FROM `$table`";
$params = [];

if ($q !== '' && !empty($searchCols)) {

    $conditions = [];

    foreach ($searchCols as $column) {
        $conditions[] = "`$column` LIKE ?";
        $params[] = '%' . $q . '%';
    }

    $sql .= " WHERE " . implode(' OR ', $conditions);
}

$sql .= " ORDER BY `" . $cfg['pk'] . "` DESC LIMIT 500";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

// Explicitly retrieve associative arrays using column names.
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ensure that only valid associative records are processed.
$rows = array_filter($rows, function ($row) {
    return is_array($row);
});

// Re-index the records.
$rows = array_values($rows);

// ------------------------------------------
// 3. Prepare visible columns
// ------------------------------------------

$visibleCols = [];

foreach ($cfg['columns'] as $column => $meta) {

    if (!empty($meta['show'])) {
        $visibleCols[] = $column;
    }

}

// ------------------------------------------
// 4. Load page header
// ------------------------------------------

require __DIR__ . '/includes/header.php';
?>

<div class="page-toolbar">

    <div>
        <p>
            Browse and manage <?= h(strtolower($cfg['label'])) ?>
            in your database.
        </p>

        <span class="soft-tag">
            <?= count($rows) ?> shown · maximum 500 per view
        </span>
    </div>

    <a class="btn btn-primary"
       href="form.php?table=<?= urlencode($table) ?>">
        ＋ Add new record
    </a>

</div>


<div class="panel data-panel">

    <div class="panel-toolbar">

        <form class="search-form" method="get">

            <input
                type="hidden"
                name="name"
                value="<?= h($table) ?>"
            >

            <span>⌕</span>

            <input
                type="search"
                name="q"
                value="<?= h($q) ?>"
                placeholder="Search <?= h(strtolower($cfg['label'])) ?>..."
            >

            <button class="btn btn-soft btn-small" type="submit">
                Search
            </button>

            <?php if ($q !== ''): ?>

                <a class="btn btn-plain btn-small"
                   href="table.php?name=<?= urlencode($table) ?>">
                    Clear
                </a>

            <?php endif; ?>

        </form>


        <div class="export-actions">

            <a class="btn btn-small btn-soft"
               href="export.php?format=csv&amp;table=<?= urlencode($table) ?>">
                ↓ CSV
            </a>

            <a class="btn btn-small btn-outline"
               href="export.php?format=pdf&amp;table=<?= urlencode($table) ?>">
                ↓ PDF
            </a>

        </div>

    </div>


    <div class="table-scroll">

        <table>

            <thead>

                <tr>

                    <?php foreach ($visibleCols as $col): ?>

                        <th>
                            <?= h($cfg['columns'][$col]['label']) ?>
                        </th>

                    <?php endforeach; ?>

                    <th class="action-head">Actions</th>

                </tr>

            </thead>


            <tbody>

                <?php if (count($rows) > 0): ?>

                    <?php foreach ($rows as $row): ?>

                        <?php
                        // Get the primary key safely.
                        $pk = $cfg['pk'];

                        $recordId = $row[$pk] ?? null;
                        ?>

                        <tr>

                            <?php foreach ($visibleCols as $col): ?>

                                <?php
                                // Get the column value safely.
                                $cellValue = $row[$col] ?? '';

                                // Convert null values into empty text.
                                if ($cellValue === null) {
                                    $cellValue = '';
                                }
                                ?>

                                <td>

                                    <?php if (
                                        in_array(
                                            $col,
                                            [
                                                'user_role',
                                                'account_status',
                                                'placement_status',
                                                'status'
                                            ],
                                            true
                                        )
                                    ): ?>

                                        <span class="status-pill">
                                            <?= h($cellValue) ?>
                                        </span>

                                    <?php else: ?>

                                        <?= h(
                                            display_value(
                                                $table,
                                                $col,
                                                $cellValue
                                            )
                                        ) ?>

                                    <?php endif; ?>

                                </td>

                            <?php endforeach; ?>


                            <td class="actions-cell">

                                <?php if ($recordId !== null): ?>

                                    <a
                                        class="btn btn-small btn-soft"
                                        href="form.php?table=<?= urlencode($table) ?>&amp;id=<?= urlencode((string)$recordId) ?>"
                                    >
                                        Edit
                                    </a>


                                    <?php if (is_staff()): ?>

                                        <form
                                            method="post"
                                            action="delete.php"
                                            class="inline-form"
                                            onsubmit="return confirm('Delete this record? This action cannot be undone.');"
                                        >

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?= h(csrf_token()) ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="table"
                                                value="<?= h($table) ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?= h($recordId) ?>"
                                            >

                                            <button
                                                class="btn btn-small btn-danger"
                                                type="submit"
                                            >
                                                Delete
                                            </button>

                                        </form>

                                    <?php endif; ?>

                                <?php else: ?>

                                    <span class="text-muted">
                                        Record ID unavailable
                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="<?= count($visibleCols) + 1 ?>"
                            class="empty-state"
                        >
                            No records found. Try another keyword or add a new record.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>


    <div class="table-foot">

        Showing <?= count($rows) ?> record(s)

        <?= $q !== '' ? ' for “' . h($q) . '”' : '' ?>.

        Search checks the searchable text fields.

    </div>

</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
