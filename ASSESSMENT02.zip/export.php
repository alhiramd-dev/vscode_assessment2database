
<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

/*
|--------------------------------------------------------------------------
| TVETMARA INDUSTRIAL TRAINING MANAGEMENT SYSTEM
| CSV AND PDF EXPORT
|--------------------------------------------------------------------------
| Features:
| 1. Export individual database tables.
| 2. Export all database tables.
| 3. CSV export.
| 4. PDF export in landscape orientation.
| 5. Proper table headings, rows and borders.
| 6. Automatic text wrapping.
| 7. Repeated headings on additional pages.
| 8. Page numbering.
| 9. Password hashes are never exported.
|--------------------------------------------------------------------------
*/


// ================================================================
// 1. VALIDATE EXPORT REQUEST
// ================================================================

$format = strtolower($_GET['format'] ?? '');
$table = $_GET['table'] ?? '';

if (!in_array($format, ['csv', 'pdf'], true)) {
    http_response_code(400);
    exit('Unsupported export format.');
}

$availableTables = table_names();

if ($table === 'all') {
    $tablesToExport = $availableTables;
} else {
    if (!in_array($table, $availableTables, true)) {
        http_response_code(400);
        exit('Invalid table selected.');
    }

    $tablesToExport = [$table];
}


// ================================================================
// 2. GET EXPORTABLE COLUMNS
// ================================================================

function sitms_export_columns(array $config): array
{
    $columns = [];

    foreach ($config['columns'] as $columnName => $metadata) {

        // Never export password hashes.
        if ($columnName === 'password_hash') {
            continue;
        }

        if (!empty($metadata['show'])) {
            $columns[] = $columnName;
        }
    }

    return $columns;
}


// ================================================================
// 3. RETRIEVE RECORDS FROM MYSQL
// ================================================================

function sitms_export_rows(
    string $tableName,
    array $columns,
    array $config
): array {

    global $pdo;

    if (empty($columns)) {
        return [];
    }

    // Confirm that the columns exist in the table configuration.
    foreach ($columns as $columnName) {
        if (!isset($config['columns'][$columnName])) {
            throw new RuntimeException('Invalid export column.');
        }
    }

    // Get the configured primary key.
    $primaryKey = $config['pk'];

    if (!isset($config['columns'][$primaryKey])) {
        throw new RuntimeException('Invalid primary key.');
    }

    // SELECT retrieves the required columns.
    // FROM identifies the selected database table.
    // ORDER BY sorts records by primary key in ascending order.
    $selectColumns = implode(
        ', ',
        array_map(
            fn($columnName) => "`$columnName`",
            $columns
        )
    );

    $sql = "SELECT $selectColumns
            FROM `$tableName`
            ORDER BY `$primaryKey` ASC";

    $statement = $pdo->query($sql);

    return $statement->fetchAll(PDO::FETCH_NUM);
}


// ================================================================
// 4. CLEAN TEXT FOR PDF
// ================================================================

function sitms_pdf_clean(string $value): string
{
    $text = $value;

    // Convert UTF-8 characters into standard PDF-compatible text.
    if (function_exists('iconv')) {

        $converted = @iconv(
            'UTF-8',
            'ASCII//TRANSLIT//IGNORE',
            $text
        );

        if ($converted !== false) {
            $text = $converted;
        }
    }

    // Remove unsupported characters and control characters.
    $text = preg_replace('/[^\x20-\x7E]/', '?', $text);

    return trim(
        str_replace(
            ["\r", "\n", "\t"],
            [' ', ' ', ' '],
            $text
        )
    );
}


// ================================================================
// 5. ESCAPE PDF SPECIAL CHARACTERS
// ================================================================

function sitms_pdf_escape(string $text): string
{
    return str_replace(
        ['\\', '(', ')'],
        ['\\\\', '\\(', '\\)'],
        $text
    );
}


// ================================================================
// 6. WRAP TEXT TO FIT INSIDE A TABLE CELL
// ================================================================

function sitms_pdf_wrap(
    string $text,
    float $cellWidth,
    float $fontSize
): array {

    $text = sitms_pdf_clean($text);

    if ($text === '') {
        return [''];
    }

    // Estimate how many characters fit inside the cell.
    $characterWidth = $fontSize * 0.52;

    $maxCharacters = max(
        4,
        (int) floor(($cellWidth - 10) / $characterWidth)
    );

    return explode(
        "\n",
        wordwrap($text, $maxCharacters, "\n", true)
    );
}


// ================================================================
// 7. DRAW TEXT ON PDF PAGE
// ================================================================

function sitms_pdf_text(
    string $text,
    float $x,
    float $top,
    float $fontSize = 8,
    array $rgb = [0.15, 0.15, 0.15]
): string {

    $pageHeight = 595;

    // Convert top-based coordinates into PDF coordinates.
    $y = $pageHeight - $top - $fontSize;

    return sprintf(
        "BT /F1 %.2F Tf %.3F %.3F %.3F rg 1 0 0 1 %.2F %.2F Tm (%s) Tj ET\n",
        $fontSize,
        $rgb[0],
        $rgb[1],
        $rgb[2],
        $x,
        $y,
        sitms_pdf_escape($text)
    );
}


// ================================================================
// 8. DRAW TABLE CELL WITH BACKGROUND AND BORDER
// ================================================================

function sitms_pdf_cell(
    float $x,
    float $top,
    float $width,
    float $height,
    array $fill = [1, 1, 1]
): string {

    $pageHeight = 595;

    $bottom = $pageHeight - $top - $height;

    $stream = '';

    // Draw cell background.
    $stream .= sprintf(
        "%.3F %.3F %.3F rg %.2F %.2F %.2F %.2F re f\n",
        $fill[0],
        $fill[1],
        $fill[2],
        $x,
        $bottom,
        $width,
        $height
    );

    // Draw cell border.
    $stream .= sprintf(
        "0.72 0.72 0.72 RG 0.45 w %.2F %.2F %.2F %.2F re S\n",
        $x,
        $bottom,
        $width,
        $height
    );

    return $stream;
}


// ================================================================
// 9. CALCULATE TABLE COLUMN WIDTHS
// ================================================================

function sitms_pdf_widths(
    array $headers,
    array $rows,
    float $totalWidth
): array {

    $weights = [];

    foreach ($headers as $index => $header) {

        $maxLength = strlen(
            sitms_pdf_clean($header)
        );

        // Examine records to estimate suitable column width.
        foreach (array_slice($rows, 0, 100) as $row) {

            $valueLength = strlen(
                sitms_pdf_clean((string)($row[$index] ?? ''))
            );

            $maxLength = max($maxLength, $valueLength);
        }

        // Limit the width so one long value cannot dominate the table.
        $weights[] = max(8, min(28, $maxLength));
    }

    $totalWeight = array_sum($weights);

    if ($totalWeight <= 0) {
        return [];
    }

    $widths = [];

    foreach ($weights as $weight) {
        $widths[] = $totalWidth * ($weight / $totalWeight);
    }

    return $widths;
}


// ================================================================
// 10. DRAW TABLE HEADER
// ================================================================

function sitms_pdf_draw_header(
    string $stream,
    array $headers,
    array $widths,
    float $currentY,
    float $fontSize
): array {

    $wrappedHeaders = [];
    $maxLines = 1;

    foreach ($headers as $index => $header) {

        $wrapped = sitms_pdf_wrap(
            $header,
            $widths[$index],
            $fontSize
        );

        $wrappedHeaders[] = $wrapped;

        $maxLines = max(
            $maxLines,
            count($wrapped)
        );
    }

    $lineHeight = $fontSize + 2;
    $rowHeight = ($maxLines * $lineHeight) + 10;

    $x = 28;

    foreach ($headers as $index => $header) {

        $width = $widths[$index];

        // Dark blue table heading background.
        $stream .= sitms_pdf_cell(
            $x,
            $currentY,
            $width,
            $rowHeight,
            [0.24, 0.32, 0.42]
        );

        foreach ($wrappedHeaders[$index] as $lineIndex => $line) {

            $stream .= sitms_pdf_text(
                $line,
                $x + 5,
                $currentY + 5 + ($lineIndex * $lineHeight),
                $fontSize,
                [1, 1, 1]
            );
        }

        $x += $width;
    }

    $currentY += $rowHeight;

    return [$stream, $currentY];
}


// ================================================================
// 11. START A NEW PDF PAGE
// ================================================================

function sitms_pdf_new_page(
    string $title,
    string $generatedDate,
    array $headers,
    array $widths,
    float $fontSize,
    int $pageNumber
): array {

    $stream = '';

    // Report title.
    $stream .= sitms_pdf_text(
        $title,
        28,
        22,
        15,
        [0.30, 0.25, 0.22]
    );

    // System name.
    $stream .= sitms_pdf_text(
        'TVETMARA Petaling Jaya - Industrial Training Management System',
        28,
        44,
        8,
        [0.35, 0.35, 0.35]
    );

    // Report generation date.
    $stream .= sitms_pdf_text(
        'Generated: ' . $generatedDate,
        28,
        58,
        8,
        [0.35, 0.35, 0.35]
    );

    $currentY = 82;

    // Draw the table header.
    [$stream, $currentY] = sitms_pdf_draw_header(
        $stream,
        $headers,
        $widths,
        $currentY,
        $fontSize
    );

    return [$stream, $currentY];
}


// ================================================================
// 12. GENERATE PDF REPORT
// ================================================================

function sitms_make_pdf(array $sections): string
{
    $pageWidth = 842;
    $pageHeight = 595;

    $margin = 28;
    $tableWidth = $pageWidth - ($margin * 2);

    $pages = [];

    $generatedDate = date('Y-m-d H:i');

    foreach ($sections as $section) {

        $headers = $section['headers'];
        $rows = $section['rows'];
        $title = $section['title'];

        if (empty($headers)) {
            continue;
        }

        $columnCount = count($headers);

        // Select font size according to the number of columns.
        if ($columnCount >= 9) {
            $fontSize = 5.8;
        } elseif ($columnCount >= 7) {
            $fontSize = 6.4;
        } else {
            $fontSize = 7.2;
        }

        $lineHeight = $fontSize + 2;

        $widths = sitms_pdf_widths(
            $headers,
            $rows,
            $tableWidth
        );

        $pageNumber = count($pages) + 1;

        // Start the first page of the selected table.
        [$stream, $currentY] = sitms_pdf_new_page(
            $title,
            $generatedDate,
            $headers,
            $widths,
            $fontSize,
            $pageNumber
        );


        // --------------------------------------------------------
        // NO RECORDS FOUND
        // --------------------------------------------------------

        if (empty($rows)) {

            $stream .= sitms_pdf_cell(
                28,
                $currentY,
                $tableWidth,
                30,
                [0.97, 0.97, 0.97]
            );

            $stream .= sitms_pdf_text(
                'No records found.',
                36,
                $currentY + 9,
                8
            );

            $currentY += 30;
        }


        // --------------------------------------------------------
        // DISPLAY DATABASE RECORDS
        // --------------------------------------------------------

        foreach ($rows as $rowIndex => $row) {

            $wrappedCells = [];
            $maxLines = 1;

            // Wrap each record value to fit its column.
            foreach ($headers as $index => $header) {

                $cellValue = (string)($row[$index] ?? '');

                $wrapped = sitms_pdf_wrap(
                    $cellValue,
                    $widths[$index],
                    $fontSize
                );

                $wrappedCells[] = $wrapped;

                $maxLines = max(
                    $maxLines,
                    count($wrapped)
                );
            }

            $rowHeight = ($maxLines * $lineHeight) + 10;

            // If the next row does not fit, start another page.
            if ($currentY + $rowHeight > 550) {

                // Save the current page.
                $pages[] = $stream;

                $pageNumber = count($pages) + 1;

                // Start the next page and repeat its table heading.
                [$stream, $currentY] = sitms_pdf_new_page(
                    $title,
                    $generatedDate,
                    $headers,
                    $widths,
                    $fontSize,
                    $pageNumber
                );
            }

            // Alternate row backgrounds.
            if ($rowIndex % 2 === 0) {
                $background = [1, 1, 1];
            } else {
                $background = [0.95, 0.96, 0.98];
            }

            $x = 28;

            foreach ($headers as $index => $header) {

                $width = $widths[$index];

                // Draw the table cell.
                $stream .= sitms_pdf_cell(
                    $x,
                    $currentY,
                    $width,
                    $rowHeight,
                    $background
                );

                // Display wrapped text inside the cell.
                foreach ($wrappedCells[$index] as $lineIndex => $line) {

                    $stream .= sitms_pdf_text(
                        $line,
                        $x + 5,
                        $currentY + 5 + ($lineIndex * $lineHeight),
                        $fontSize,
                        [0.15, 0.15, 0.15]
                    );
                }

                $x += $width;
            }

            $currentY += $rowHeight;
        }

        // Save the final page for this table.
        $pages[] = $stream;
    }


    // If no sections contain exportable data.
    if (empty($pages)) {

        $pages[] = sitms_pdf_text(
            'No exportable data found.',
            28,
            40,
            10
        );
    }


    // ============================================================
    // 13. ADD FOOTERS AND PAGE NUMBERS
    // ============================================================

    $totalPages = count($pages);

    foreach ($pages as $index => &$pageStream) {

        $pageStream .= sitms_pdf_text(
            'TVETMARA Industrial Training Management System',
            28,
            570,
            7,
            [0.45, 0.45, 0.45]
        );

        $pageStream .= sitms_pdf_text(
            'Page ' . ($index + 1) . ' of ' . $totalPages,
            760,
            570,
            7,
            [0.45, 0.45, 0.45]
        );
    }

    unset($pageStream);


    // ============================================================
    // 14. CREATE PDF OBJECTS
    // ============================================================

    $objects = [];

    // Main PDF catalog.
    $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';

    // Standard Helvetica font.
    $objects[3] =
        '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';

    $kids = [];

    $nextObject = 4;

    foreach ($pages as $pageStream) {

        $pageObject = $nextObject++;
        $contentObject = $nextObject++;

        $kids[] = "$pageObject 0 R";

        // Page definition.
        $objects[$pageObject] =
            "<< /Type /Page /Parent 2 0 R " .
            "/MediaBox [0 0 $pageWidth $pageHeight] " .
            "/Resources << /Font << /F1 3 0 R >> >> " .
            "/Contents $contentObject 0 R >>";

        // Page content.
        $objects[$contentObject] =
            "<< /Length " . strlen($pageStream) . " >>\n" .
            "stream\n" .
            $pageStream .
            "\nendstream";
    }

    // Pages collection.
    $objects[2] =
        '<< /Type /Pages /Kids [' .
        implode(' ', $kids) .
        '] /Count ' . count($pages) .
        ' >>';


    // ============================================================
    // 15. BUILD FINAL PDF FILE
    // ============================================================

    ksort($objects);

    $pdf = "%PDF-1.4\n";

    $offsets = [0];

    $maximumObject = max(array_keys($objects));

    for ($i = 1; $i <= $maximumObject; $i++) {

        $offsets[$i] = strlen($pdf);

        $pdf .=
            "$i 0 obj\n" .
            ($objects[$i] ?? '<<>>') .
            "\nendobj\n";
    }

    // Cross-reference table.
    $xrefPosition = strlen($pdf);

    $pdf .=
        "xref\n0 " . ($maximumObject + 1) .
        "\n0000000000 65535 f \n";

    for ($i = 1; $i <= $maximumObject; $i++) {

        $pdf .= sprintf(
            "%010d 00000 n \n",
            $offsets[$i]
        );
    }

    // PDF trailer.
    $pdf .=
        "trailer\n<< /Size " . ($maximumObject + 1) .
        " /Root 1 0 R >>\n" .
        "startxref\n$xrefPosition\n%%EOF";

    return $pdf;
}


// ================================================================
// 16. PREPARE ALL SELECTED TABLES
// ================================================================

$sections = [];

foreach ($tablesToExport as $tableName) {

    $config = get_table_config($tableName);

    if (!$config || empty($config['columns'])) {
        continue;
    }

    $columns = sitms_export_columns($config);

    $rows = sitms_export_rows(
        $tableName,
        $columns,
        $config
    );

    $headers = [];

    foreach ($columns as $columnName) {
        $headers[] = $config['columns'][$columnName]['label'];
    }

    $sections[] = [
        'table' => $tableName,
        'title' => $config['label'],
        'headers' => $headers,
        'rows' => $rows
    ];
}


// ================================================================
// 17. EXPORT CSV
// ================================================================

if ($format === 'csv') {

    $filename =
        ($table === 'all' ? 'all_training_tables' : strtolower($table)) .
        '_' . date('Ymd_His') . '.csv';

    header('Content-Type: text/csv; charset=utf-8');

    header(
        'Content-Disposition: attachment; filename="' .
        $filename .
        '"'
    );

    $output = fopen('php://output', 'w');

    // UTF-8 BOM improves compatibility with Microsoft Excel.
    fwrite($output, "\xEF\xBB\xBF");

    foreach ($sections as $section) {

        fputcsv(
            $output,
            ['TABLE: ' . $section['table']]
        );

        fputcsv(
            $output,
            $section['headers']
        );

        foreach ($section['rows'] as $row) {
            fputcsv($output, $row);
        }

        fputcsv($output, []);
    }

    fclose($output);
    exit;
}


// ================================================================
// 18. EXPORT PDF
// ================================================================

$pdf = sitms_make_pdf($sections);

$filename =
    ($table === 'all' ? 'all_training_tables' : strtolower($table)) .
    '_' . date('Ymd_His') . '.pdf';

header('Content-Type: application/pdf');

header(
    'Content-Disposition: attachment; filename="' .
    $filename .
    '"'
);

header('Content-Length: ' . strlen($pdf));

echo $pdf;
exit;
