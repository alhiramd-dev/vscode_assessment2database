document.addEventListener('DOMContentLoaded', () => {

    const toggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');

    // Open and close the sidebar on mobile devices.
    if (toggle && sidebar) {

        toggle.addEventListener('click', () => {
            sidebar.classList.toggle('sidebar-open');
        });

    }

    // Add a small click animation to buttons.
    document.querySelectorAll('.btn').forEach(button => {

        button.addEventListener('click', () => {

            button.classList.add('is-pressed');

            window.setTimeout(() => {
                button.classList.remove('is-pressed');
            }, 160);

        });

    });

});