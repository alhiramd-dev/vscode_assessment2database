<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$pageTitle = 'Dashboard';

$totalRecords = 0;
$counts = [];

foreach (table_names() as $name) {
    $counts[$name] = count_table($name);
    $totalRecords += $counts[$name];
}

$recent = $pdo->query("
    SELECT
        s.student_id,
        s.student_name,
        p.placement_status,
        c.company_name
    FROM Student s
    LEFT JOIN Placement p
        ON s.student_id = p.student_id
    LEFT JOIN Company c
        ON p.company_id = c.company_id
    ORDER BY s.student_id DESC
    LIMIT 6
")->fetchAll();

require __DIR__ . '/includes/header.php';
?>

<section class="welcome-panel">

    <div>

        <span class="welcome-kicker">
            <?= is_staff()
                ? 'STAFF WORKSPACE · FULL RECORD ACCESS'
                : 'ADMIN CONTROL DESK · RECORD OVERSIGHT'
            ?>
            ✧
        </span>

        <h2>
            <?= is_staff()
                ? 'Ready to manage records?'
                : 'Welcome to your control desk,'
            ?>

            <?= is_staff() ? '' : h($_SESSION['full_name']) . '!' ?>
        </h2>

        <p>
            <?= is_staff()
                ? 'You can view, add, update and delete industrial training records across all nine tables.'
                : 'You can monitor the database and view, add or update records across all nine tables.'
            ?>
        </p>

        <a class="btn btn-primary" href="tables.php">
            <?= is_staff() ? 'Open staff workspace' : 'Open admin workspace' ?>
            <span>→</span>
        </a>

    </div>

    <div class="welcome-art" aria-hidden="true">

        <span class="art-flower">✿</span>
        <span class="art-star">✧</span>

        <div class="art-window">

            <div class="art-window-top">
                my workspace.exe
            </div>

            <div class="art-window-body">
                <span>♡</span>
                <span>▤</span>
                <span>✿</span>
            </div>

        </div>

    </div>

</section>


<div class="section-heading">

    <div>
        <span class="eyebrow">DATABASE SNAPSHOT</span>
        <h2>Everything in one place</h2>
    </div>

    <span class="soft-tag">Updated live ✿</span>

</div>


<div class="stats-grid">

    <article class="stat-card stat-pink">
        <div class="stat-icon">▤</div>
        <span>Total records</span>
        <strong><?= number_format($totalRecords) ?></strong>
        <small>Across all 9 tables</small>
    </article>

    <article class="stat-card stat-yellow">
        <div class="stat-icon">🎓</div>
        <span>Students</span>
        <strong><?= number_format($counts['Student']) ?></strong>
        <small>Student profiles</small>
    </article>

    <article class="stat-card stat-green">
        <div class="stat-icon">🏢</div>
        <span>Companies</span>
        <strong><?= number_format($counts['Company']) ?></strong>
        <small>Training partners</small>
    </article>

    <article class="stat-card stat-blue">
        <div class="stat-icon">📌</div>
        <span>Placements</span>
        <strong><?= number_format($counts['Placement']) ?></strong>
        <small>Placement records</small>
    </article>

</div>


<div class="section-heading">

    <div>
        <span class="eyebrow">QUICK ACCESS</span>
        <h2>Database collections</h2>
    </div>

    <a class="text-link" href="tables.php">
        View all tables →
    </a>

</div>


<div class="collection-grid">

    <?php foreach ($TABLES as $name => $cfg): ?>

        <a class="collection-card" href="table.php?name=<?= urlencode($name) ?>">

            <span class="collection-icon">
                <?= h($cfg['icon']) ?>
            </span>

            <span class="collection-name">
                <?= h($cfg['label']) ?>
            </span>

            <strong>
                <?= number_format($counts[$name]) ?>
            </strong>

            <small>
                records <span>↗</span>
            </small>

        </a>

    <?php endforeach; ?>

</div>


<div class="section-heading">

    <div>
        <span class="eyebrow">LATEST STUDENT OVERVIEW</span>
        <h2>Recent placement records</h2>
    </div>

</div>


<div class="panel table-panel">

    <div class="table-scroll">

        <table>

            <thead>
                <tr>
                    <th>Student</th>
                    <th>Name</th>
                    <th>Company</th>
                    <th>Status</th>
                </tr>
            </thead>

            <tbody>

                <?php foreach ($recent as $row): ?>

                    <tr>

                        <td><?= h($row['student_id']) ?></td>

                        <td><?= h($row['student_name']) ?></td>

                        <td>
                            <?= h($row['company_name'] ?? 'Not assigned') ?>
                        </td>

                        <td>
                            <span class="status-pill">
                                <?= h($row['placement_status'] ?? 'Unassigned') ?>
                            </span>
                        </td>

                    </tr>

                <?php endforeach; ?>

                <?php if (!$recent): ?>

                    <tr>
                        <td colspan="4" class="empty-state">
                            No student records yet.
                        </td>
                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<?php require __DIR__ . '/includes/footer.php'; ?>