
<?php
require_once __DIR__ . '/includes/auth.php';

// CHANGE THIS TO YOUR OWN PRIVATE SETUP KEY.
const ADMIN_SETUP_KEY = 'CHANGE_THIS_TO_A_LONG_PRIVATE_KEY_2026';

$error = '';
$success = '';

$adminCheck = $pdo->query(
    "SELECT COUNT(*) FROM SystemUser WHERE user_role = 'Admin'"
);
$adminExists = (int)$adminCheck->fetchColumn() > 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$adminExists) {
    verify_csrf();

    $setupKey = $_POST['setup_key'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!hash_equals(ADMIN_SETUP_KEY, $setupKey)) {
        $error = 'Invalid setup key.';
    } elseif (
        $full_name === '' || $username === '' || $email === '' ||
        $password === '' || $confirm_password === ''
    ) {
        $error = 'Please complete all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($username) < 4) {
        $error = 'Username must contain at least 4 characters.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must contain at least 8 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'The passwords do not match.';
    } else {
        $check = $pdo->prepare(
            "SELECT user_id FROM SystemUser
             WHERE username = :username OR email = :email
             LIMIT 1"
        );

        $check->execute([
            ':username' => $username,
            ':email' => $email
        ]);

        if ($check->fetch()) {
            $error = 'That username or email is already registered.';
        } else {
            $password_hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $insert = $pdo->prepare(
                "INSERT INTO SystemUser
                (username, password_hash, full_name, email, user_role, account_status)
                VALUES
                (:username, :password_hash, :full_name, :email, 'Admin', 'Active')"
            );

            $insert->execute([
                ':username' => $username,
                ':password_hash' => $password_hash,
                ':full_name' => $full_name,
                ':email' => $email
            ]);

            $success = 'Your first Admin account has been created. You can now sign in.';
            $adminExists = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Initial Admin Setup | TVETMARA</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">

<main class="auth-card">

    <div class="auth-logo">
        <img src="assets/images/tvetmara-logo.png"
             alt="TVETMARA Logo"
             onerror="this.style.display='none';">
    </div>

    <p class="auth-institution">TVETMARA PETALING JAYA</p>
    <h1>Initial Admin Setup</h1>
    <p class="auth-subtitle">Create the first system administrator account.</p>

    <?php if ($error !== ''): ?>
        <div class="auth-alert auth-error"><?= h($error) ?></div>
    <?php endif; ?>

    <?php if ($success !== ''): ?>
        <div class="auth-alert auth-success">
            <?= h($success) ?>
            <p><a href="login.php">Go to sign in</a></p>
        </div>

    <?php elseif ($adminExists): ?>
        <div class="auth-alert auth-error">
            An Admin account already exists. Initial setup is closed.
            <p><a href="login.php">Go to sign in</a></p>
        </div>

    <?php else: ?>

        <form method="POST" action="setup_admin.php">
            <input type="hidden" name="csrf_token"
                   value="<?= h(csrf_token()) ?>">

            <label for="setup_key">Private setup key</label>
            <input type="password" id="setup_key" name="setup_key"
                   placeholder="Enter your setup key" required>

            <label for="full_name">Full name</label>
            <input type="text" id="full_name" name="full_name"
                   placeholder="Enter your full name"
                   maxlength="100" required>

            <label for="username">Username</label>
            <input type="text" id="username" name="username"
                   placeholder="Choose an Admin username"
                   minlength="4" maxlength="50" required>

            <label for="email">Email address</label>
            <input type="email" id="email" name="email"
                   placeholder="Enter your email"
                   maxlength="100" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password"
                   placeholder="At least 8 characters"
                   minlength="8" required>

            <label for="confirm_password">Confirm password</label>
            <input type="password" id="confirm_password"
                   name="confirm_password"
                   placeholder="Enter your password again"
                   minlength="8" required>

            <button type="submit" class="auth-button">
                Create Admin account
            </button>
        </form>

    <?php endif; ?>

    <p class="auth-footer">
        Already have an account? <a href="login.php">Sign in</a>
    </p>

</main>
</body>
</html>
