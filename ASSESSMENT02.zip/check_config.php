
<?php

require_once __DIR__ . '/includes/functions.php';

echo '<h2>Table Configuration Diagnostic</h2>';

$table = 'LecturerSupervisor';

echo '<h3>1. Loaded table name</h3>';
echo '<pre>';
var_dump($table);
echo '</pre>';

$cfg = get_table_config($table);

echo '<h3>2. Primary key</h3>';
echo '<pre>';
var_dump($cfg['pk'] ?? 'MISSING');
echo '</pre>';

echo '<h3>3. Loaded column configuration</h3>';
echo '<pre>';
var_dump($cfg['columns'] ?? 'MISSING');
echo '</pre>';

echo '<h3>4. Check each column label</h3>';

foreach (($cfg['columns'] ?? []) as $column => $meta) {

    echo '<p>';

    echo 'Column: ' . htmlspecialchars($column);

    echo ' | Label: ' .
        htmlspecialchars($meta['label'] ?? 'MISSING LABEL');

    echo '</p>';

}

echo '<h3>5. Configuration file location</h3>';

echo '<pre>';
echo realpath(__DIR__ . '/includes/table_config.php');
echo '</pre>';

?>
