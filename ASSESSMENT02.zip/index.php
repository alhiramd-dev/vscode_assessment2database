
<?php

// Load the authentication file using the absolute project path.
$authFile = __DIR__ . '/includes/auth.php';

// Check whether the authentication file exists.
if (!file_exists($authFile)) {
    exit(
        'ERROR: auth.php is missing. Please create the includes folder ' .
        'and place auth.php inside it.'
    );
}

require_once $authFile;

// Redirect users based on their login status.
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

header('Location: login.php');
exit;

