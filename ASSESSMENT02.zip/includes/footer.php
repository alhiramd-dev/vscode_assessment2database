        </div>

        <footer class="footer">
            A little more organised, one record at a time
            <span>✿</span>
        </footer>

    </main>

</div>

<script src="assets/js/app.js"></script>

</body>
</html>