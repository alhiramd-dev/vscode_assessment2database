
<?php

// Start the session if it has not already started.
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Connect to the database.
require_once __DIR__ . '/../config/database.php';

// Load CSRF security functions.
require_once __DIR__ . '/csrf.php';


// Check whether the user is logged in.
function is_logged_in(): bool {

    return !empty($_SESSION['user_id']);

}


// Redirect users who are not logged in.
function require_login(): void {

    if (!is_logged_in()) {

        header('Location: login.php');
        exit;

    }

}


// Get the current user's role.
function current_role(): string {

    return $_SESSION['user_role'] ?? '';

}


// Check whether the logged-in user is Staff.
function is_staff(): bool {

    return current_role() === 'Staff';

}


// Only allow Staff to perform deletion.
function require_staff(): void {

    require_login();

    if (!is_staff()) {

        http_response_code(403);

        exit('Access denied. Only Staff accounts can delete records.');

    }

}


// Safely display text to prevent HTML injection.
function h($value): string {

    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );

}

