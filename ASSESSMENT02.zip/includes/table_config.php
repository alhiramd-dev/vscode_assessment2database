<?php
// This file describes the existing database tables.
// It does NOT create, rename or modify any database tables.

$TABLES = [

    // 1. STUDENT TABLE
    'Student' => [
        'label' => 'Students',
        'icon' => '🎓',
        'pk' => 'student_id',
        'columns' => [
            'student_id' => ['label'=>'Student ID','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'matrix_no' => ['label'=>'Matrix Number','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'student_name' => ['label'=>'Student Name','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'programme' => ['label'=>'Programme','type'=>'text','required'=>false,'search'=>true,'show'=>true],
            'phone_no' => ['label'=>'Phone Number','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'email' => ['label'=>'Email','type'=>'email','required'=>true,'search'=>true,'show'=>true],
            'cgpa' => ['label'=>'CGPA','type'=>'number','step'=>'0.01','required'=>false,'search'=>false,'show'=>true]
        ]
    ],

    // 2. COMPANY TABLE
    'Company' => [
        'label' => 'Companies',
        'icon' => '🏢',
        'pk' => 'company_id',
        'columns' => [
            'company_id' => ['label'=>'Company ID','type'=>'number','auto'=>true,'show'=>true],
            'company_name' => ['label'=>'Company Name','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'address' => ['label'=>'Address','type'=>'textarea','required'=>true,'search'=>true,'show'=>true],
            'contact_person' => ['label'=>'Contact Person','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'phone_no' => ['label'=>'Phone Number','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'email' => ['label'=>'Email','type'=>'email','required'=>true,'search'=>true,'show'=>true]
        ]
    ],

    // 3. INDUSTRIAL SUPERVISOR TABLE
    'IndustrialSupervisor' => [
        'label' => 'Industrial Supervisors',
        'icon' => '🧑‍🔧',
        'pk' => 'ind_sup_id',
        'columns' => [
            'ind_sup_id' => ['label'=>'Supervisor ID','type'=>'number','auto'=>true,'show'=>true],
            'company_id' => [
                'label'=>'Company',
                'type'=>'fk',
                'required'=>true,
                'search'=>false,
                'show'=>true,
                'fk'=>[
                    'table'=>'Company',
                    'value'=>'company_id',
                    'label'=>'company_name'
                ]
            ],
            'sup_name' => ['label'=>'Supervisor Name','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'designation' => ['label'=>'Designation','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'phone_no' => ['label'=>'Phone Number','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'email' => ['label'=>'Email','type'=>'email','required'=>true,'search'=>true,'show'=>true]
        ]
    ],

    // 4. LECTURER SUPERVISOR TABLE
    'LecturerSupervisor' => [
        'label' => 'Lecturer Supervisors',
        'icon' => '👩‍🏫',
        'pk' => 'lec_sup_id',
        'columns' => [
            'lec_sup_id' => ['label'=>'Lecturer ID','type'=>'number','auto'=>true,'show'=>true],
            'lec_name' => ['label'=>'Lecturer Name','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'department' => ['label'=>'Department','type'=>'text','required'=>false,'search'=>true,'show'=>true],
            'phone_no' => ['label'=>'Phone Number','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'email' => ['label'=>'Email','type'=>'email','required'=>true,'search'=>true,'show'=>true],
            'office_room' => ['label'=>'Office Room','type'=>'text','required'=>true,'search'=>true,'show'=>true]
        ]
    ],

    // 5. PLACEMENT TABLE
    'Placement' => [
        'label' => 'Placements',
        'icon' => '📌',
        'pk' => 'placement_id',
        'columns' => [
            'placement_id' => ['label'=>'Placement ID','type'=>'number','auto'=>true,'show'=>true],

            'student_id' => [
                'label'=>'Student',
                'type'=>'fk',
                'required'=>true,
                'search'=>false,
                'show'=>true,
                'fk'=>[
                    'table'=>'Student',
                    'value'=>'student_id',
                    'label'=>'student_name'
                ]
            ],

            'company_id' => [
                'label'=>'Company',
                'type'=>'fk',
                'required'=>true,
                'search'=>false,
                'show'=>true,
                'fk'=>[
                    'table'=>'Company',
                    'value'=>'company_id',
                    'label'=>'company_name'
                ]
            ],

            'ind_sup_id' => [
                'label'=>'Industrial Supervisor',
                'type'=>'fk',
                'required'=>true,
                'search'=>false,
                'show'=>true,
                'fk'=>[
                    'table'=>'IndustrialSupervisor',
                    'value'=>'ind_sup_id',
                    'label'=>'sup_name'
                ]
            ],

            'lec_sup_id' => [
                'label'=>'Lecturer Supervisor',
                'type'=>'fk',
                'required'=>true,
                'search'=>false,
                'show'=>true,
                'fk'=>[
                    'table'=>'LecturerSupervisor',
                    'value'=>'lec_sup_id',
                    'label'=>'lec_name'
                ]
            ],

            'placement_status' => [
                'label'=>'Placement Status',
                'type'=>'select',
                'options'=>['Pending','Approved','Rejected','Completed'],
                'required'=>false,
                'search'=>true,
                'show'=>true
            ],

            'start_date' => ['label'=>'Start Date','type'=>'date','required'=>true,'search'=>false,'show'=>true],
            'end_date' => ['label'=>'End Date','type'=>'date','required'=>true,'search'=>false,'show'=>true]
        ]
    ],

    // 6. INDUSTRIAL VISIT TABLE
    'IndustrialVisit' => [
        'label' => 'Industrial Visits',
        'icon' => '🚗',
        'pk' => 'visit_id',
        'columns' => [
            'visit_id' => ['label'=>'Visit ID','type'=>'number','auto'=>true,'show'=>true],

            'placement_id' => [
                'label'=>'Placement',
                'type'=>'fk',
                'required'=>true,
                'search'=>false,
                'show'=>true,
                'fk'=>[
                    'table'=>'Placement',
                    'value'=>'placement_id',
                    'label'=>'placement_id'
                ]
            ],

            'visit_date' => ['label'=>'Visit Date','type'=>'date','required'=>true,'search'=>false,'show'=>true],

            'status' => [
                'label'=>'Visit Status',
                'type'=>'select',
                'options'=>['Scheduled','Completed','Cancelled'],
                'required'=>false,
                'search'=>true,
                'show'=>true
            ],

            'visit_report' => ['label'=>'Visit Report','type'=>'textarea','required'=>false,'search'=>true,'show'=>true]
        ]
    ],

    // 7. LOGBOOK TABLE
    'Logbook' => [
        'label' => 'Logbooks',
        'icon' => '📒',
        'pk' => 'log_id',
        'columns' => [
            'log_id' => ['label'=>'Log ID','type'=>'number','auto'=>true,'show'=>true],

            'placement_id' => [
                'label'=>'Placement',
                'type'=>'fk',
                'required'=>true,
                'search'=>false,
                'show'=>true,
                'fk'=>[
                    'table'=>'Placement',
                    'value'=>'placement_id',
                    'label'=>'placement_id'
                ]
            ],

            'week_no' => ['label'=>'Week Number','type'=>'number','step'=>'1','required'=>true,'search'=>false,'show'=>true],
            'submission_date' => ['label'=>'Submission Date','type'=>'date','required'=>true,'search'=>false,'show'=>true],
            'task_summary' => ['label'=>'Task Summary','type'=>'textarea','required'=>true,'search'=>true,'show'=>true],
            'supervisor_feedback' => ['label'=>'Supervisor Feedback','type'=>'text','required'=>false,'search'=>true,'show'=>true],

            'status' => [
                'label'=>'Logbook Status',
                'type'=>'select',
                'options'=>['Submitted','Approved','Rejected'],
                'required'=>false,
                'search'=>true,
                'show'=>true
            ]
        ]
    ],

    // 8. EVALUATION TABLE
    'Evaluation' => [
        'label' => 'Evaluations',
        'icon' => '⭐',
        'pk' => 'eval_id',
        'columns' => [
            'eval_id' => ['label'=>'Evaluation ID','type'=>'number','auto'=>true,'show'=>true],

            'placement_id' => [
                'label'=>'Placement',
                'type'=>'fk',
                'required'=>true,
                'search'=>false,
                'show'=>true,
                'fk'=>[
                    'table'=>'Placement',
                    'value'=>'placement_id',
                    'label'=>'placement_id'
                ]
            ],

            'evaluation_type' => [
                'label'=>'Evaluation Type',
                'type'=>'select',
                'options'=>['Midterm','Final'],
                'required'=>false,
                'search'=>true,
                'show'=>true
            ],

            'technical_score' => ['label'=>'Technical Score','type'=>'number','step'=>'0.01','required'=>true,'search'=>false,'show'=>true],
            'soft_skills_score' => ['label'=>'Soft Skills Score','type'=>'number','step'=>'0.01','required'=>true,'search'=>false,'show'=>true],
            'total_score' => ['label'=>'Total Score','type'=>'number','step'=>'0.01','required'=>true,'search'=>false,'show'=>true],
            'grade' => ['label'=>'Grade','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'eval_date' => ['label'=>'Evaluation Date','type'=>'date','required'=>true,'search'=>false,'show'=>true]
        ]
    ],

    // 9. SYSTEM USER TABLE
    'SystemUser' => [
        'label' => 'System Users',
        'icon' => '👤',
        'pk' => 'user_id',
        'columns' => [
            'user_id' => ['label'=>'User ID','type'=>'number','auto'=>true,'show'=>true],
            'username' => ['label'=>'Username','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'password_hash' => ['label'=>'Password Hash','type'=>'password_hash','required'=>true,'show'=>false],
            'full_name' => ['label'=>'Full Name','type'=>'text','required'=>true,'search'=>true,'show'=>true],
            'email' => ['label'=>'Email','type'=>'email','required'=>true,'search'=>true,'show'=>true],

            'user_role' => [
                'label'=>'User Role',
                'type'=>'select',
                'options'=>['Admin','Staff'],
                'required'=>true,
                'search'=>true,
                'show'=>true
            ],

            'account_status' => [
                'label'=>'Account Status',
                'type'=>'select',
                'options'=>['Active','Inactive'],
                'required'=>false,
                'search'=>true,
                'show'=>true
            ]
        ]
    ]

];