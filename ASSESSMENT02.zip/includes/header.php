<?php
$pageTitle = $pageTitle ?? 'Dashboard';
$activeTable = $activeTable ?? '';
$flash = get_flash();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= h($pageTitle) ?> | TVETMARA Training</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Nunito:wght@500;600;700;800&family=Quicksand:wght@500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="app-body role-<?= h(strtolower(current_role())) ?>">

<div class="app-shell">

    <?php require __DIR__ . '/sidebar.php'; ?>

    <main class="main-area">

        <header class="topbar">

            <button class="mobile-menu" id="menuToggle" aria-label="Open navigation">
                ☰
            </button>

            <div>
                <div class="eyebrow">
                    TVETMARA PETALING JAYA · INDUSTRIAL TRAINING
                </div>

                <h1><?= h($pageTitle) ?></h1>
            </div>

            <div class="top-user">

                <span class="avatar">
                    <?= h(strtoupper(substr($_SESSION['full_name'] ?? 'U', 0, 1))) ?>
                </span>

                <div>
                    <strong><?= h($_SESSION['full_name'] ?? 'User') ?></strong>
                    <small><?= h(current_role()) ?></small>
                </div>

                <a class="logout-link" href="logout.php">Log out</a>

            </div>

        </header>

        <div class="content-wrap">

            <?php if ($flash): ?>
                <div class="alert alert-<?= h($flash['type']) ?>">
                    <?= h($flash['message']) ?>
                </div>
            <?php endif; ?>