
<aside class="sidebar" id="sidebar">

    <a class="brand" href="dashboard.php">
        <span class="brand-mark">✿</span>

        <span>
            <b>Training</b>
            <small>management desk</small>
        </span>
    </a>

    <div class="sidebar-label">WORKSPACE</div>

    <nav class="nav-list">

        <a class="<?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>"
           href="dashboard.php">
            <span>⌂</span> Dashboard
        </a>

        <a class="<?= basename($_SERVER['PHP_SELF']) === 'tables.php' ? 'active' : '' ?>"
           href="tables.php">
            <span>▤</span> All database tables
        </a>

    </nav>

    <div class="sidebar-label">DATABASE TABLES</div>

    <nav class="nav-list table-nav">

        <?php foreach ($TABLES as $sidebarTableName => $sidebarTableConfig): ?>

            <a class="<?= $activeTable === $sidebarTableName ? 'active' : '' ?>"
               href="table.php?name=<?= urlencode($sidebarTableName) ?>">

                <span><?= h($sidebarTableConfig['icon']) ?></span>
                <?= h($sidebarTableConfig['label']) ?>

            </a>

        <?php endforeach; ?>

    </nav>

    <div class="sidebar-note">
        <span>🍓</span>
        <b>Little reminder</b>

        <p>
            Keep every training record neat, complete and up to date.
        </p>
    </div>

    <div class="sidebar-bottom">
        Made for organised training ✧
    </div>

</aside>
