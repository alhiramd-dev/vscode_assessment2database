
<?php

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/table_config.php';


// ------------------------------------------
// Get table configuration
// ------------------------------------------

function get_table_config(string $table): array {

    global $TABLES;

    if (!isset($TABLES[$table])) {

        http_response_code(404);
        exit('Unknown table.');

    }

    return $TABLES[$table];

}


// ------------------------------------------
// Get all table names
// ------------------------------------------

function table_names(): array {

    global $TABLES;

    return array_keys($TABLES);

}


// ------------------------------------------
// Get primary key
// ------------------------------------------

function get_primary_key(string $table): string {

    $cfg = get_table_config($table);

    return $cfg['pk'];

}


// ------------------------------------------
// Get one database record
// ------------------------------------------

function get_record(string $table, $id): ?array {

    global $pdo;

    $cfg = get_table_config($table);

    $pk = $cfg['pk'];

    $stmt = $pdo->prepare(
        "SELECT * FROM `$table` WHERE `$pk` = ? LIMIT 1"
    );

    $stmt->execute([$id]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return is_array($row) ? $row : null;

}


// ------------------------------------------
// Get foreign key dropdown options
// ------------------------------------------

function get_fk_options(array $fk): array {

    global $pdo;

    $table = $fk['table'];
    $value = $fk['value'];
    $label = $fk['label'];

    $stmt = $pdo->query(
        "SELECT `$value` AS option_value,
                `$label` AS option_label
         FROM `$table`
         ORDER BY `$label`"
    );

    return $stmt->fetchAll(PDO::FETCH_ASSOC);

}


// ------------------------------------------
// Flash messages
// ------------------------------------------

function set_flash(string $type, string $message): void {

    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];

}


function get_flash(): ?array {

    $flash = $_SESSION['flash'] ?? null;

    unset($_SESSION['flash']);

    return $flash;

}


// ------------------------------------------
// Count records in a table
// ------------------------------------------

function count_table(string $table): int {

    global $pdo;

    get_table_config($table);

    return (int) $pdo
        ->query("SELECT COUNT(*) FROM `$table`")
        ->fetchColumn();

}


// ------------------------------------------
// Format values for table display
// ------------------------------------------

function display_value(
    string $table,
    string $column,
    $value
): string {

    // Never display the actual password hash.
    if (
        $table === 'SystemUser' &&
        $column === 'password_hash'
    ) {

        return '••••••••';

    }

    return (string) ($value ?? '');

}
