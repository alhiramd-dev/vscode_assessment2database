
<?php

// Start the session if it has not already started.
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}


// Generate a security token for forms.
function csrf_token(): string {

    if (empty($_SESSION['csrf_token'])) {

        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    }

    return $_SESSION['csrf_token'];

}


// Verify the token when a form is submitted.
function verify_csrf(): void {

    $token = $_POST['csrf_token'] ?? '';

    if (
        !$token ||
        !hash_equals($_SESSION['csrf_token'] ?? '', $token)
    ) {

        http_response_code(419);

        exit(
            'Invalid security token. Refresh the page and try again.'
        );

    }

}

