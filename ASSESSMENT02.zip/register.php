
<?php
require_once __DIR__ . '/includes/auth.php';

// CHANGE THIS TO YOUR OWN PRIVATE STAFF REGISTRATION KEY.
const STAFF_REGISTRATION_KEY = 'tvetmara staff';

// Redirect logged-in users.
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';
$selectedRole = 'Admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $full_name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $selectedRole = $_POST['user_role'] ?? 'Admin';
    $staffKey = $_POST['staff_key'] ?? '';

    if (!in_array($selectedRole, ['Admin', 'Staff'], true)) {
        $error = 'Please select a valid account type.';
    } elseif (
        $full_name === '' || $username === '' || $email === '' ||
        $password === '' || $confirm_password === ''
    ) {
        $error = 'Please complete all fields.';
    } elseif (
        $selectedRole === 'Staff' &&
        !hash_equals(STAFF_REGISTRATION_KEY, $staffKey)
    ) {
        $error = 'Incorrect Staff registration key.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($username) < 4) {
        $error = 'Username must contain at least 4 characters.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must contain at least 8 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'The passwords do not match.';
    } else {
        // Check for duplicate username or email.
        $check = $pdo->prepare(
            "SELECT user_id FROM SystemUser
             WHERE username = :username OR email = :email
             LIMIT 1"
        );

        $check->execute([
            ':username' => $username,
            ':email' => $email
        ]);

        if ($check->fetch()) {
            $error = 'That username or email is already registered.';
        } else {
            $password_hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $insert = $pdo->prepare(
                "INSERT INTO SystemUser
                (username, password_hash, full_name, email, user_role, account_status)
                VALUES
                (:username, :password_hash, :full_name, :email, :user_role, 'Active')"
            );

            $insert->execute([
                ':username' => $username,
                ':password_hash' => $password_hash,
                ':full_name' => $full_name,
                ':email' => $email,
                ':user_role' => $selectedRole
            ]);

            $success = $selectedRole .
                ' account created successfully! You can now sign in.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Create Account | TVETMARA Industrial Training</title>

    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="auth-page">

<div class="auth-decoration flower-decoration">✿</div>
<div class="auth-decoration star-decoration">✧</div>

<main class="auth-card">

    <div class="auth-logo">
        <img
            src="assets/images/tvetmara-logo.png"
            alt="TVETMARA Logo"
            onerror="this.style.display='none';"
        >
    </div>

    <p class="auth-institution">TVETMARA PETALING JAYA</p>

    <h1>Create your account</h1>

    <p class="auth-subtitle">
        Join your industrial training workspace.
    </p>

    <?php if ($error !== ''): ?>
        <div class="auth-alert auth-error">
            <?= h($error) ?>
        </div>
    <?php endif; ?>

    <?php if ($success !== ''): ?>

        <div class="auth-alert auth-success">
            <?= h($success) ?>
            <p><a href="login.php">Go to sign in</a></p>
        </div>

    <?php else: ?>

    <form method="POST" action="register.php">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= h(csrf_token()) ?>"
        >

        <label for="user_role">Register as</label>

        <select
            id="user_role"
            name="user_role"
            required
            onchange="toggleStaffKey()"
        >
            <option value="Admin"
                <?= $selectedRole === 'Admin' ? 'selected' : '' ?>>
                Admin - View, Insert and Update
            </option>

            <option value="Staff"
                <?= $selectedRole === 'Staff' ? 'selected' : '' ?>>
                Staff - Full Access
            </option>
        </select>

        <div id="staffKeySection"
             style="display: <?= $selectedRole === 'Staff' ? 'block' : 'none' ?>;">

            <label for="staff_key">Staff Registration Key</label>

            <input
                type="password"
                id="staff_key"
                name="staff_key"
                placeholder="Enter Staff registration key"
                autocomplete="off"
                <?= $selectedRole === 'Staff' ? 'required' : '' ?>
            >

            <small style="display:block; margin-top:6px;">
                A valid key is required to register as Staff.
            </small>

        </div>

        <label for="full_name">Full name</label>

        <input
            type="text"
            id="full_name"
            name="full_name"
            placeholder="Enter your full name"
            value="<?= h($_POST['full_name'] ?? '') ?>"
            maxlength="100"
            required
        >

        <label for="username">Username</label>

        <input
            type="text"
            id="username"
            name="username"
            placeholder="Choose a username"
            value="<?= h($_POST['username'] ?? '') ?>"
            minlength="4"
            maxlength="50"
            autocomplete="username"
            required
        >

        <label for="email">Email address</label>

        <input
            type="email"
            id="email"
            name="email"
            placeholder="Enter your email"
            value="<?= h($_POST['email'] ?? '') ?>"
            maxlength="100"
            required
        >

        <label for="password">Password</label>

        <input
            type="password"
            id="password"
            name="password"
            placeholder="At least 8 characters"
            minlength="8"
            autocomplete="new-password"
            required
        >

        <label for="confirm_password">Confirm password</label>

        <input
            type="password"
            id="confirm_password"
            name="confirm_password"
            placeholder="Enter your password again"
            minlength="8"
            autocomplete="new-password"
            required
        >

        <button type="submit" class="auth-button">
            Create account ♡
        </button>

    </form>

    <?php endif; ?>

    <p class="auth-footer">
        Already have an account?
        <a href="login.php">Sign in here</a>
    </p>

    <p class="auth-security">
        ✧ Admin and Staff registration · Secure account creation ✧
    </p>

</main>

<script>
function toggleStaffKey() {
    const role = document.getElementById('user_role').value;
    const section = document.getElementById('staffKeySection');
    const keyInput = document.getElementById('staff_key');

    if (role === 'Staff') {
        section.style.display = 'block';
        keyInput.required = true;
    } else {
        section.style.display = 'none';
        keyInput.required = false;
        keyInput.value = '';
    }
}
</script>

</body>
</html>
