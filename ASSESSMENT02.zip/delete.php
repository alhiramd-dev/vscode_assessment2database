<?php
require_once __DIR__ . '/includes/functions.php';

// Only Staff accounts are allowed to delete records.
require_staff();

// Deletion must use POST, not a normal URL request.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

verify_csrf();

$table = $_POST['table'] ?? '';
$id = $_POST['id'] ?? '';

$cfg = get_table_config($table);
$pk = $cfg['pk'];

try {

    $stmt = $pdo->prepare(
        "DELETE FROM `$table` WHERE `$pk` = ?"
    );

    $stmt->execute([$id]);

    set_flash(
        $stmt->rowCount() ? 'success' : 'error',
        $stmt->rowCount()
            ? 'Record deleted successfully.'
            : 'No matching record was found.'
    );

} catch (PDOException $e) {

    set_flash(
        'error',
        'The record could not be deleted. It may be linked to other records. Database message: ' .
        $e->getMessage()
    );

}

header('Location: table.php?name=' . urlencode($table));
exit;